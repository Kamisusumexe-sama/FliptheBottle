System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var spine = exports("default", 'assets/spine-BUh5FZoK.wasm'); /* asset-hash:2d59702f */

		})
	};
}));
